const colors = require("colors");
function showBanner() {
  console.log(colors.yellow("Tool Shared By FOREST ARMY (https://t.me/airdropscriptFA)"));
}

module.exports = { showBanner };
